# COMP 3612 (Fall 2024)
### Assignment #1: HTML+CSS

**Please view `COMP3612 Assignment 1.pdf` for instructions**

  
